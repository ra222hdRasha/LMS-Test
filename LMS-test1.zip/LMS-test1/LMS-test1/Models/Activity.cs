﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LMS_test1.Models
{
    public class Activity
    {
        //Primary Key
        [Key]
        public int activityId { get; set;}

        [Display(Name = "Owner Name")]
        public string name { get; set;}

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? StartDate { get; set; }


        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? EndDate { get; set; }

        [Display(Name = "Description")]
        public string description { get; set; }

        //[Display(Name = "Start Date/Time")]
        //public DateTime startDate { get; set; }
        //[Display(Name = "End Date/Time")]
        //public DateTime endDate { get; set; }

        [Display(Name = "Attachment")]
        public string linkedFile { get; set;}


        // Connection
        [Display(Name = "Owner")]
        public int ownerGroupId    { get; set;}       //FK to Group
        [ForeignKey("ownerGroupId")]
        public virtual Group groups { get; set; }

    }
}