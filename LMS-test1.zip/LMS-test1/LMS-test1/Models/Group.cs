﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace LMS_test1.Models
{
    public class Group
    {
        //Primary Key
        [Key]
        public int groupID { get; set; }        


        //Attributes
        [Display(Name = "Max. No. of Members")]
        public int maxMembers { get; set; }

        [Display(Name = "Group Name")]
        public string groupName { get; set; }

        [Display(Name = "Location")]
        public string classLocation { get; set; }

        [Display(Name = "Description")]
        public string groupDescription { get; set; }

        //Conncections
        public virtual ICollection<GroupFile> groupFile { get; set; }
        public virtual ICollection<Activity> Activities { get; set; }
        public virtual ICollection<ApplicationUser> User { get; set; }
 
        //public int? groupFileId { get; set; }   //FK to GroupFile
        //public int ActivityId { get; set; }     //FK to Activity Table

    }
}