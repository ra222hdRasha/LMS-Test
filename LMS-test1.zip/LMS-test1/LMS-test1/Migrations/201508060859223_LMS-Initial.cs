namespace LMS_test1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class LMSInitial : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Activities", "StartDate", c => c.DateTime());
            AddColumn("dbo.Activities", "EndDate", c => c.DateTime());
            AddColumn("dbo.Activities", "description", c => c.String());
            DropColumn("dbo.Activities", "DataofStart");
            DropColumn("dbo.Activities", "DataofEnd");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Activities", "DataofEnd", c => c.DateTime());
            AddColumn("dbo.Activities", "DataofStart", c => c.DateTime());
            DropColumn("dbo.Activities", "description");
            DropColumn("dbo.Activities", "EndDate");
            DropColumn("dbo.Activities", "StartDate");
        }
    }
}
