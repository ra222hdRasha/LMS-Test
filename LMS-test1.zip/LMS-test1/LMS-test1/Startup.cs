﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(LMS_test1.Startup))]
namespace LMS_test1
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
